import java.lang.*;
import java.util.*;
import java.io.*;
public class Main {
    
public static void main(String[] args) {
   ReadMonsterCardFromFile(); 
  ProgramController test = new ProgramController();
   test.run();


  
          }
public static void ReadMonsterCardFromFile(){
    
    String monstercard[] = new String[246];
    int i = 0;
    try (Scanner scanner = new Scanner(new File("MonsterCard.txt"))) {
 
    while (scanner.hasNext()){
        monstercard[i] = scanner.nextLine();
        i=i+1;
    }
 
} catch (IOException e) {
    System.out.println("ERROR FROM REDING FILE");
}
   for (i = 0; i < 246; i=i+6){
    new MonsterCard( monstercard[i], monstercard[i+1], monstercard[i+5],Integer.parseInt(monstercard[i+2]) ,Integer.parseInt(monstercard[i+3]) ,Integer.parseInt(monstercard[i+4]));
   }

}
public static void ReadTrapSpellCardFromFile(){
    String spelltarpcard[] = new String[132];
    int i = 0;
    try (Scanner scanner = new Scanner(new File("SpellTrapCard.txt"))) {
 
    while (scanner.hasNext()){
        spelltarpcard[i] = scanner.nextLine();
        i=i+1;
    }
 
} catch (IOException e) {
    System.out.println("ERROR FROM REDING FILE");
}
   for (i = 0; i < 132; i=i+4){
    if (spelltarpcard[i+1].equals("Spell")) 
    {new JadoCard(spelltarpcard[i],spelltarpcard[i+2], spelltarpcard[i+5]) ;}
    else
    {new TaleCard( spelltarpcard[i], spelltarpcard[i+2], spelltarpcard[i+5]) ;}
  
}

}


    }

