
import java.util.*;
import java.util.regex.*;



public  class ProgramController {
   public String CurrentUsername;
   public boolean Islogin = false ;
   public String CurrentPassword;
   public String CurrentNickame;
   public String CurrentMenu = new String("login");
   public void run(){
       int d=0;
      Scanner scan = new Scanner(System.in);
      ArrayList<String> line = new ArrayList<String>();
        for (int i=0;true;i++){
          line.add(scan.nextLine()) ;                                                                                       //start regex      
          if (line.get(i).equals("end"))  break; 
        if (getCommandMatcher(line.get(i), ("^user create --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)>$"))!=null) 
         {UserCreate(getCommandMatcher(line.get(i), ("^user create --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)>$")));continue;}

        if (getCommandMatcher(line.get(i), ("^user login --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)>$"))!=null) 
         {/*erja tabe;*/continue;}

        if (getCommandMatcher(line.get(i), ("^user logout$"))!=null)  
        {/*erja tabe;*/continue;}

        if (getCommandMatcher(line.get(i), ("^scoreboard show$"))!=null)  
        {/*erja tabe;*/continue;}

        if (getCommandMatcher(line.get(i), ("^profile change --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)>$"))!=null) 
         {/*erja tabe;*/continue;}

        if (getCommandMatcher(line.get(i), ("^profile change --([A-Za-z0-9_]*) --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)> --([A-Za-z0-9_]*) <([A-Za-z0-9_]*)>$"))!=null)  
        {/*erja tabe;*/continue;} 
       
        if (getCommandMatcher(line.get(i), ("^menu enter <([a-zA-Z0-9_])>$"))!=null) 
         {/*erja tabe;*/continue;}

        if (getCommandMatcher(line.get(i), ("^menu exit$"))!=null)  {if (CurrentMenu.equals("login")) break; 
        else {/*erja tabe;*/continue;}}

        if (getCommandMatcher(line.get(i), ("^menu show-current$"))!=null) 
         {System.out.println(CurrentMenu);continue;} 
       
        if (getCommandMatcher(line.get(i), ("^deck create ([a-zA-Z0-9_]*)$"))!=null) 
         {/*erja tabe;*/continue;} 

        if (getCommandMatcher(line.get(i), ("^deck delete ([a-zA-Z0-9_]*)$"))!=null) 
         {/*erja tabe;*/continue;} 

         
        
         if (getCommandMatcher(line.get(i), ("^deck add-card --([a-zA-Z0-9_]*) <([a-zA-Z0-9_]*)> --([a-zA-Z0-9_]*) <([a-zA-Z0-9_]*)>([a-zA-Z0-9_ ]+)$"))!=null) 
         {/*erja tabe;*/continue;} 
      
                   
        
          System.out.println("invalid command");
       
        }
    }
   
    private void UserCreate (Matcher matcher){
     if (!(CurrentMenu.equals("login"))) System.out.println("invalid command");
     else{ 
      String password = new String("");
      String username = new String("");
      String nickname = new String("");
      for (int i = 1;i < 7 ;i=i+2){
         if (matcher.group(i).equals("password")) {password = matcher.group(i+1);}
      else if (matcher.group(i).equals("usename")) {username = matcher.group(i+1);}
           else  {nickname =  matcher.group(i+1);}
        }
      if (Player.GetPlayerBySTH(username, 1) != null) System.out.println("user with username "+username+" already exists");
      else if (Player.GetPlayerBySTH(nickname,2) != null)  System.out.println("user with nickname "+nickname+" already exists");
            else  {new Player(username , password , nickname , 0);CurrentUsername = username;CurrentPassword = password;CurrentNickame = nickname;}}
      
    }

      private void login(Matcher matcher){
        if (!(CurrentMenu.equals("login"))) System.out.println("invalid command");
       else {
        String Password;
        String Username;
       
        if (matcher.group(1).equals("username"))  {Username = matcher.group(2); Password = matcher.group(4);}
        else {Username = matcher.group(4); Password = matcher.group(2);}
     
      if (Player.GetPlayerBySTH(Username,1) == null) System.out.println("Username and password didn’t match!");
      else if (!(Player.GetPlayerBySTH(Username,1).getPassword().equals(Password)))   System.out.println("Username and password didn’t match!");
       else {Islogin=true;CurrentUsername=Username;CurrentPassword=Password;CurrentMenu="menu";}
    }}
    
    private void logout(){
      if (CurrentMenu.equals("main menu")) System.out.println("invalid command");
      else {
     System.out.println("user logged out successfully!");
      Islogin=false;
      CurrentUsername=null;
      CurrentPassword=null;
    }}

    private void ScoreboardShow(){                                        
     String Username[] = new String[Player.palyers.size()];
     int Score[] = new int[Player.palyers.size()];
     int LastScore[] = new int[Player.palyers.size()];
     int i=0;
     for (Player player : Player.palyers) {
     Username[i] = player.getUsername();
     Score[i] = player.getScore();
    LastScore[i] = player.getScore();
     i++;
     }
    int a = 1;
     Arrays.sort(LastScore);
     for (int j = i - 1; j >= 0 ; j--){
       for (int z = 0 ; z < i;z++){
         if (LastScore[j]==Score[z])  {
          if (LastScore[j] == LastScore[j+1]) {a=a-1;}
          System.out.println(a+"-"+Username[z]+": "+LastScore[j]);a=a+1;break;}
       }

     }
    }

     private void ChangeNickname(Matcher matcher){
      if (!(CurrentMenu.equals("profie"))) System.out.println("invalid command");
     else{
      String Nickame = matcher.group(2);
      if (Player.GetPlayerBySTH(Nickame, 2) == null) System.out.println("user with nickname "+Nickame+" already exists");
      else Player.GetPlayerBySTH(CurrentUsername,1).SetNickname(Nickame);
    }}
    
    private void ChangePassword(Matcher matcher){
      if (!(CurrentMenu.equals("profile"))) System.out.println("invalid command");
     else {
      String NewPassword ;
      String LastPassword ;
      if (matcher.group(2).equals("current")) {NewPassword = matcher.group(5);LastPassword = matcher.group(3);}
      else {NewPassword = matcher.group(3);LastPassword = matcher.group(5);}
      if (!(CurrentPassword.equals(LastPassword)) )  System.out.println("current password is invalid");
      else   if (NewPassword.equals(LastPassword)) System.out.println("please enter a new password");
           else Player.GetPlayerBySTH(CurrentUsername,1).SetNickname(NewPassword);
    }}

    private void ExitMenu(){
      if (CurrentMenu.equals("menu"))  CurrentMenu = "login";
      //kamel nist
    }
   
   

    private void createDeck(Matcher matcher){
     String deckname = matcher.group(1); 
     if (Deck.GetDeckByName(CurrentUsername, deckname) != null) System.out.println("deck with name "+deckname+" already exists");
        else {new Deck(CurrentUsername, deckname, false);System.out.println("deck created successfully!");}
       }

      public void DeleteDeck(Matcher matcher){
        String deckname = matcher.group(1);
        if (Deck.GetDeckByName(CurrentUsername, deckname) == null) System.out.println("deck with name "+deckname+" does not exists");
           else {Deck.GetDeckByName(CurrentUsername, deckname).DeleteDeck(CurrentUsername, deckname);System.out.println("deck deleted successfully");}
         }


     public void AddCardToDeck(Matcher matcher){
     String cardname;
     String deckname;
     boolean maindeck = true;
      if (matcher.group(1).equals("card")) {cardname = matcher.group(2);deckname = matcher.group(4);}
      else {cardname = matcher.group(4);deckname = matcher.group(2);}
      if (matcher.group(5).equals("side"))  maindeck = false;
      if ((MonsterCard.IsNameExist(cardname)==null)&&(TaleCard.IsNameExist(cardname)==null)&&(JadoCard.IsNameExist(cardname)==null)) System.out.println("card with name "+cardname+" does not exis");
      else if (Deck.GetDeckByName(CurrentUsername, deckname)==null)    System.out.println("deck with name "+deckname+" does not exist");
           else if ((maindeck==true)&&(Deck.GetDeckByName(CurrentUsername, deckname).MainDecksize()==60))   System.out.println("main deck is full");
                else if ((maindeck==false)&&(Deck.GetDeckByName(CurrentUsername, deckname).SideDecksize()==15))   System.out.println("side deck is full");
                     else if ((maindeck==true)&&(Deck.GetDeckByName(CurrentUsername, deckname).AmountCardInDeck(cardname)==3))   System.out.println("there are already three cards with name "+cardname+" in deck "+deckname);
                          else if ((maindeck==false)&&(Deck.GetDeckByName(CurrentUsername, deckname).AmountCardInDeck(cardname)==3))   System.out.println("there are already three cards with name "+cardname+" in deck "+deckname);
                               else {System.out.println("card added to deck successfully");
                               if (maindeck==true)       Deck.GetDeckByName(CurrentUsername, deckname).AddCardToMainDeck(cardname);
                               else   Deck.GetDeckByName(CurrentUsername, deckname).AddCardToSideDeck(cardname);  }  
                              }  
        
   /*   public void AddCardToDeck(Matcher matcher){
         String cardname;
         String deckname;
         boolean maindeck = true;  
         if (matcher.group(5).equals("side"))  maindeck = false;
         if (matcher.group(1).equals("card")) {cardname = matcher.group(2);deckname = matcher.group(4);}
          else {cardname = matcher.group(4);deckname = matcher.group(2);}  
         
          if (Deck.GetDeckByName(deckname)==null)    System.out.println("deck with name "+deckname+" does not exist");
          else  if ((MonsterCard.IsNameExist(cardname)==null)&&(TaleCard.IsNameExist(cardname)==null)&&(JadoCard.IsNameExist(cardname)==null)) System.out.println("card with name "+cardname+" does not exis");
          else {System.out.println("card removed form deck successfully");
          if (maindeck==true)        Deck.GetDeckByName(deckname).DeleteCardFromMainDeck(cardname);
           else   Deck.GetDeckByName(deckname).DeleteCardFromSideDeck(cardname);  } 



          }     */              

    private Matcher getCommandMatcher(String input,String regex){               

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);

        if (matcher.find()) return matcher; 
         else    return null;
    }
}
