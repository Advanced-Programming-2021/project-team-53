import java.util.*;

public class JadoCard {
    private   String Name;
    private  String Type;
    private  String Description;
    
    static  ArrayList<JadoCard> jadocards = new ArrayList<JadoCard>();
    public   JadoCard(String name, String type, String description){
        this.Name = name;
        this.Type = type;
        this.Description = description;
        jadocards.add(this);
    }
    public static JadoCard IsNameExist(String name){
        int i;
        for ( i = 0 ; i < jadocards.size(); i++) {
          if (name.equals(jadocards.get(i).getname()))       break;
        }       
       if (i == jadocards.size())     return null;
       else  return  jadocards.get(i);
        
    }
    public String getname(){
        return Name;
    }
    public String gettype(){
        return Type;
    }
    public String getDescription(){
        return Description;
    }
    
}
