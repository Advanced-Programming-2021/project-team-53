import java.util.ArrayList;



public class MonsterCard {
  private   String Name;
  private  String Type;
  private  String Description;
  private  int Level;
  private  int Attack;
  private  int Defend;
  static  ArrayList<MonsterCard> monstercards = new ArrayList<MonsterCard>();
  public   MonsterCard(String name, String type, String description,int level,int attack,int defend){
    this.Name = name;
    this.Type = type;
    this.Description = description;
    this.Level = level;
    this.Attack = attack;
    this.Defend = defend;
    monstercards.add(this);
}
public static MonsterCard IsNameExist(String name){
    int i;
    for ( i = 0 ; i < monstercards.size(); i++) {
      if (name.equals(monstercards.get(i).getname()))       break;
    }       
   if (i == monstercards.size())     return null;
   else  return  monstercards.get(i);
    
}
public String getname(){
    return Name;
}
public String gettype(){
    return Type;
}
public String getDescription(){
    return Description;
}
public int getLevel(){
    return Level;
}
public int getAttack(){
    return Attack;
}
public int getDefend(){
    return Defend;
}





}