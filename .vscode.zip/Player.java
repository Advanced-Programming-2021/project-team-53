import java.util.*;

public class Player {
    private String Username;
    private String Password;
    private String Nickname;
    private int  Score=0;
    static  ArrayList<Player> palyers = new ArrayList<Player>();
    public static String CurrentUsername;
   

   public static  Player GetPlayerBySTH(String name , int number){
  // boolean ExistCheck = false ;
    if (number == 1){for (Player player : palyers) {
      if   (player.getUsername().equals(name)) {return player;}
     }}
    else if (number == 2){for (Player player : palyers) {
         if   (player.getNickname().equals(name)) {return player;}
       }}
        else if (number ==3){for (Player player : palyers) {
             if   (player.Password.equals(name)) {return player;}
           }
        
        }
        
      return null;
   
    }


  public  Player ( String username, String password, String nickname, int score){

    this.Username = username ;
    this.Password = password ;
    this.Nickname = nickname ;
    this.Score = score ;

    palyers.add(this);


  }
public String getNickname(){
    return Nickname;
}
public String getPassword(){
    return Password;
}
public String getUsername(){
    return Username;
}

public int getScore(){
    return Score;
}

public void SetNickname(String NewNickname){
    Nickname = NewNickname;
}
public void SetPasswrd(String NewPassword){
    Password = NewPassword;
}

public void IncreaseScore(int NewScore){
Score =Score+ NewScore;


}
}
