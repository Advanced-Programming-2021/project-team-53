import java.util.*;

public class TaleCard {
    private   String Name;
    private  String Type;
    private  String Description;
   
    static  ArrayList<TaleCard> talecards = new ArrayList<TaleCard>();
    public   TaleCard(String name, String type, String description){
        this.Name = name;
        this.Type = type;
        this.Description = description;
        talecards.add(this);
    }
    public static TaleCard IsNameExist(String name){
        int i;
        for ( i = 0 ; i < talecards.size(); i++) {
          if (name.equals(talecards.get(i).getname()))       break;
        }       
       if (i == talecards.size())     return null;
       else  return  talecards.get(i);
        
    }
    public String getname(){
        return Name;
    }
    public String gettype(){
        return Type;
    }
    public String getDescription(){
        return Description;
    }
}
